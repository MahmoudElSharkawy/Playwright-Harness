# Defects and cases needing attention

These are recorded failures, blockers and review findings, not filed product bugs.

## case\-2 — Failed

Case 2 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-4 — Blocked

Case 4 · A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-8 — Needs review

Case 8 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-12 — Failed

Case 12 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-16 — Blocked

Case 16 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-20 — Failed

Case 20 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-22 — Failed

Case 22 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-24 — Blocked

Case 24 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-28 — Needs review

Case 28 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-32 — Failed

Case 32 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-36 — Blocked

Case 36 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-40 — Failed

Case 40 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-42 — Failed

Case 42 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-44 — Blocked

Case 44 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-48 — Needs review

Case 48 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-52 — Failed

Case 52 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-56 — Blocked

Case 56 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-60 — Failed

Case 60 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-62 — Failed

Case 62 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-64 — Blocked

Case 64 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-68 — Needs review

Case 68 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-72 — Failed

Case 72 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-76 — Blocked

Case 76 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-80 — Failed

Case 80 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-82 — Failed

Case 82 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-84 — Blocked

Case 84 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-88 — Needs review

Case 88 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-92 — Failed

Case 92 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-96 — Blocked

Case 96 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-100 — Failed

Case 100 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-102 — Failed

Case 102 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-104 — Blocked

Case 104 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-108 — Needs review

Case 108 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-112 — Failed

Case 112 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-116 — Blocked

Case 116 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-120 — Failed

Case 120 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

