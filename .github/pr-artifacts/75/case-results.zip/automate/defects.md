# Defects and cases needing attention

These are recorded failures, blockers and review findings, not filed product bugs.

## case\-2 — FAIL

Case 2 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-4 — BLOCKED

Case 4 · A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-8 — NEEDS_REVIEW

Case 8 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-12 — FAIL

Case 12 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-16 — BLOCKED

Case 16 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-20 — FAIL

Case 20 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-22 — FAIL

Case 22 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-24 — BLOCKED

Case 24 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-28 — NEEDS_REVIEW

Case 28 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-32 — FAIL

Case 32 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-36 — BLOCKED

Case 36 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-40 — FAIL

Case 40 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-42 — FAIL

Case 42 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-44 — BLOCKED

Case 44 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-48 — NEEDS_REVIEW

Case 48 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-52 — FAIL

Case 52 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-56 — BLOCKED

Case 56 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-60 — FAIL

Case 60 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-62 — FAIL

Case 62 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-64 — BLOCKED

Case 64 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-68 — NEEDS_REVIEW

Case 68 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-72 — FAIL

Case 72 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-76 — BLOCKED

Case 76 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-80 — FAIL

Case 80 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-82 — FAIL

Case 82 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-84 — BLOCKED

Case 84 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-88 — NEEDS_REVIEW

Case 88 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-92 — FAIL

Case 92 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-96 — BLOCKED

Case 96 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-100 — FAIL

Case 100 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-102 — FAIL

Case 102 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-104 — BLOCKED

Case 104 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-108 — NEEDS_REVIEW

Case 108 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-112 — FAIL

Case 112 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-116 — BLOCKED

Case 116 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-120 — FAIL

Case 120 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

