# Synthetic automation report

## case\-1 — Passed

Case 1 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-2 — Failed

Case 2 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-3 — Passed

Case 3 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-4 — Blocked

Case 4 · A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-5 — Passed

Case 5 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-6 — Not generated

Case 6 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-7 — Passed

Case 7 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-8 — Needs review

Case 8 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-9 — Passed

Case 9 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-10 — Passed

Case 10 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-11 — Passed

Case 11 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-12 — Failed

Case 12 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-13 — Passed

Case 13 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-14 — Passed

Case 14 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-15 — Passed

Case 15 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-16 — Blocked

Case 16 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-17 — Passed

Case 17 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-18 — Not generated

Case 18 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-19 — Passed

Case 19 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-20 — Failed

Case 20 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-21 — Passed

Case 21 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-22 — Failed

Case 22 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-23 — Passed

Case 23 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-24 — Blocked

Case 24 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-25 — Passed

Case 25 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-26 — Not generated

Case 26 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-27 — Passed

Case 27 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-28 — Needs review

Case 28 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-29 — Passed

Case 29 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-30 — Passed

Case 30 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-31 — Passed

Case 31 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-32 — Failed

Case 32 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-33 — Passed

Case 33 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-34 — Passed

Case 34 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-35 — Passed

Case 35 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-36 — Blocked

Case 36 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-37 — Passed

Case 37 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-38 — Not generated

Case 38 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-39 — Passed

Case 39 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-40 — Failed

Case 40 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-41 — Passed

Case 41 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-42 — Failed

Case 42 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-43 — Passed

Case 43 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-44 — Blocked

Case 44 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-45 — Passed

Case 45 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-46 — Not generated

Case 46 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-47 — Passed

Case 47 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-48 — Needs review

Case 48 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-49 — Passed

Case 49 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-50 — Passed

Case 50 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-51 — Passed

Case 51 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-52 — Failed

Case 52 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-53 — Passed

Case 53 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-54 — Passed

Case 54 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-55 — Passed

Case 55 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-56 — Blocked

Case 56 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-57 — Passed

Case 57 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-58 — Not generated

Case 58 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-59 — Passed

Case 59 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-60 — Failed

Case 60 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-61 — Passed

Case 61 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-62 — Failed

Case 62 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-63 — Passed

Case 63 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-64 — Blocked

Case 64 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-65 — Passed

Case 65 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-66 — Not generated

Case 66 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-67 — Passed

Case 67 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-68 — Needs review

Case 68 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-69 — Passed

Case 69 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-70 — Passed

Case 70 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-71 — Passed

Case 71 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-72 — Failed

Case 72 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-73 — Passed

Case 73 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-74 — Passed

Case 74 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-75 — Passed

Case 75 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-76 — Blocked

Case 76 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-77 — Passed

Case 77 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-78 — Not generated

Case 78 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-79 — Passed

Case 79 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-80 — Failed

Case 80 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-81 — Passed

Case 81 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-82 — Failed

Case 82 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-83 — Passed

Case 83 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-84 — Blocked

Case 84 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-85 — Passed

Case 85 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-86 — Not generated

Case 86 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-87 — Passed

Case 87 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-88 — Needs review

Case 88 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-89 — Passed

Case 89 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-90 — Passed

Case 90 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-91 — Passed

Case 91 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-92 — Failed

Case 92 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-93 — Passed

Case 93 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-94 — Passed

Case 94 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-95 — Passed

Case 95 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-96 — Blocked

Case 96 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-97 — Passed

Case 97 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-98 — Not generated

Case 98 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-99 — Passed

Case 99 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-100 — Failed

Case 100 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-101 — Passed

Case 101 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-102 — Failed

Case 102 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-103 — Passed

Case 103 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-104 — Blocked

Case 104 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-105 — Passed

Case 105 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-106 — Not generated

Case 106 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-107 — Passed

Case 107 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-108 — Needs review

Case 108 · A detailed synthetic source title 

Stage: Review

Reason: Independent approval is missing\.

## case\-109 — Passed

Case 109 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-110 — Passed

Case 110 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-111 — Passed

Case 111 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-112 — Failed

Case 112 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

## case\-113 — Passed

Case 113 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-114 — Passed

Case 114 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-115 — Passed

Case 115 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-116 — Blocked

Case 116 · A detailed synthetic source title 

Stage: Exploration

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-117 — Passed

Case 117 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-118 — Not generated

Case 118 · A detailed synthetic source title 

Stage: Automation

Reason: No generated candidate exists\.

## case\-119 — Passed

Case 119 · A detailed synthetic source title 

Stage: Verification

Reason: The native test passed; readiness is still incomplete\.

## case\-120 — Failed

Case 120 · A detailed synthetic source title 

Stage: Verification

Reason: 1 check\(s\) failed\.

Next action: Investigate the recorded failed assertion\.

