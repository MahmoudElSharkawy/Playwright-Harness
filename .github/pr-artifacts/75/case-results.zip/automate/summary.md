# Synthetic automation report

Source: synthetic\-source

Automation readiness: NEEDS\_REVIEW · 0 / 2 scoped greens · 1 / 3 repair rounds

## case\-1 — PASS

Case 1 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-2 — FAIL

Case 2 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-3 — PASS

Case 3 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-4 — BLOCKED

Case 4 · A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-5 — PASS

Case 5 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-6 — NOT_GENERATED

Case 6 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-7 — PASS

Case 7 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-8 — NEEDS_REVIEW

Case 8 · A detailed synthetic source title 

Stage: REVIEW

Reason: Independent approval is missing\.

## case\-9 — PASS

Case 9 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-10 — PASS

Case 10 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-11 — PASS

Case 11 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-12 — FAIL

Case 12 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-13 — PASS

Case 13 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-14 — PASS

Case 14 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-15 — PASS

Case 15 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-16 — BLOCKED

Case 16 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-17 — PASS

Case 17 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-18 — NOT_GENERATED

Case 18 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-19 — PASS

Case 19 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-20 — FAIL

Case 20 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-21 — PASS

Case 21 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-22 — FAIL

Case 22 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-23 — PASS

Case 23 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-24 — BLOCKED

Case 24 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-25 — PASS

Case 25 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-26 — NOT_GENERATED

Case 26 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-27 — PASS

Case 27 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-28 — NEEDS_REVIEW

Case 28 · A detailed synthetic source title 

Stage: REVIEW

Reason: Independent approval is missing\.

## case\-29 — PASS

Case 29 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-30 — PASS

Case 30 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-31 — PASS

Case 31 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-32 — FAIL

Case 32 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-33 — PASS

Case 33 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-34 — PASS

Case 34 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-35 — PASS

Case 35 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-36 — BLOCKED

Case 36 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-37 — PASS

Case 37 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-38 — NOT_GENERATED

Case 38 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-39 — PASS

Case 39 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-40 — FAIL

Case 40 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-41 — PASS

Case 41 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-42 — FAIL

Case 42 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-43 — PASS

Case 43 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-44 — BLOCKED

Case 44 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-45 — PASS

Case 45 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-46 — NOT_GENERATED

Case 46 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-47 — PASS

Case 47 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-48 — NEEDS_REVIEW

Case 48 · A detailed synthetic source title 

Stage: REVIEW

Reason: Independent approval is missing\.

## case\-49 — PASS

Case 49 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-50 — PASS

Case 50 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-51 — PASS

Case 51 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-52 — FAIL

Case 52 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-53 — PASS

Case 53 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-54 — PASS

Case 54 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-55 — PASS

Case 55 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-56 — BLOCKED

Case 56 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-57 — PASS

Case 57 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-58 — NOT_GENERATED

Case 58 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-59 — PASS

Case 59 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-60 — FAIL

Case 60 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-61 — PASS

Case 61 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-62 — FAIL

Case 62 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-63 — PASS

Case 63 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-64 — BLOCKED

Case 64 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-65 — PASS

Case 65 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-66 — NOT_GENERATED

Case 66 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-67 — PASS

Case 67 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-68 — NEEDS_REVIEW

Case 68 · A detailed synthetic source title 

Stage: REVIEW

Reason: Independent approval is missing\.

## case\-69 — PASS

Case 69 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-70 — PASS

Case 70 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-71 — PASS

Case 71 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-72 — FAIL

Case 72 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-73 — PASS

Case 73 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-74 — PASS

Case 74 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-75 — PASS

Case 75 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-76 — BLOCKED

Case 76 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-77 — PASS

Case 77 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-78 — NOT_GENERATED

Case 78 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-79 — PASS

Case 79 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-80 — FAIL

Case 80 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-81 — PASS

Case 81 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-82 — FAIL

Case 82 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-83 — PASS

Case 83 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-84 — BLOCKED

Case 84 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-85 — PASS

Case 85 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-86 — NOT_GENERATED

Case 86 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-87 — PASS

Case 87 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-88 — NEEDS_REVIEW

Case 88 · A detailed synthetic source title 

Stage: REVIEW

Reason: Independent approval is missing\.

## case\-89 — PASS

Case 89 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-90 — PASS

Case 90 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-91 — PASS

Case 91 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-92 — FAIL

Case 92 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-93 — PASS

Case 93 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-94 — PASS

Case 94 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-95 — PASS

Case 95 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-96 — BLOCKED

Case 96 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-97 — PASS

Case 97 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-98 — NOT_GENERATED

Case 98 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-99 — PASS

Case 99 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-100 — FAIL

Case 100 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-101 — PASS

Case 101 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-102 — FAIL

Case 102 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-103 — PASS

Case 103 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-104 — BLOCKED

Case 104 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-105 — PASS

Case 105 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-106 — NOT_GENERATED

Case 106 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-107 — PASS

Case 107 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-108 — NEEDS_REVIEW

Case 108 · A detailed synthetic source title 

Stage: REVIEW

Reason: Independent approval is missing\.

## case\-109 — PASS

Case 109 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-110 — PASS

Case 110 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-111 — PASS

Case 111 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-112 — FAIL

Case 112 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

## case\-113 — PASS

Case 113 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-114 — PASS

Case 114 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-115 — PASS

Case 115 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-116 — BLOCKED

Case 116 · A detailed synthetic source title 

Stage: EXPLORE

Reason: The required QA account and customer fixture are unavailable\.

Next action: Provision the QA account and fixture, then resume\.

## case\-117 — PASS

Case 117 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-118 — NOT_GENERATED

Case 118 · A detailed synthetic source title 

Stage: AUTHOR

Reason: No generated candidate exists\.

## case\-119 — PASS

Case 119 · A detailed synthetic source title 

Stage: VERIFY

Reason: The native test passed; readiness is still incomplete\.

## case\-120 — FAIL

Case 120 · A detailed synthetic source title 

Stage: VERIFY

Reason: 1 native assertion failed \(toHaveText\)\.

Next action: Investigate the recorded failed assertion\.

