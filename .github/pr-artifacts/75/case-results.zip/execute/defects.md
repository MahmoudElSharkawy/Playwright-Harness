# Defect list

- Verify the failed service response: Status is 200 (1 occurrence(s))
