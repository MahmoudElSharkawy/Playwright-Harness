# Synthetic execution

Execution: execute-494650bf-63e6-41fc-add9-df5dafe9f7be

| Scenario | Outcome | Checked / observed / mixed |
|---|---|---|
| tc\-101\-r1 | PASS | 1 / 0 / 0 |
| tc\-102\-r1 | FAIL | 1 / 0 / 0 |
| tc\-103\-r1 | BLOCKED | 0 / 0 / 0 |
| tc\-104\-r1 | NOT_RUN | 0 / 0 / 0 |

Exclusions: 0. Defect groups: 1.
