# Synthetic execution

## Case 101: Read the available fixture

Status: PASS

## Case 102: Verify the failed service response

Status: FAIL

Reason: Failed check: Status is 200 Recorded result: 500

Next action: Review the expected and actual results, then fix the cause\.

## Case 103: Use the unavailable customer fixture

Status: BLOCKED

Reason: The customer fixture is unavailable in this synthetic example\.

Next action: Provision the fixture, then resume this case\.

## Case 104: Execute the remaining source case

Status: NOT_RUN

Reason: No execution has been recorded for this case\.

