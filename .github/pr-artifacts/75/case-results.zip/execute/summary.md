# Synthetic execution

## Case 101: Read the available fixture

Status: Passed

## Case 102: Verify the failed service response

Status: Failed

Reason: Failed check: Status is 200 Recorded result: 500

Next action: Review the expected and actual results, then fix the cause\.

## Case 103: Use the unavailable customer fixture

Status: Blocked

Reason: The customer fixture is unavailable in this synthetic example\.

Next action: Provision the fixture, then resume this case\.

## Case 104: Execute the remaining source case

Status: Not run

Reason: No execution has been recorded for this case\.

