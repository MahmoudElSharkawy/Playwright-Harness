Execution and automation report UX samples.

Open execute/index.html or automate/index.html in a browser. Both work offline.

The execution example contains four synthetic cases: one passed and one failed against a disposable local API, one recorded prerequisite blocker and one not-run case. The complete generated directory retains companion reports and integrity receipts.

The automation example is the 120-case synthetic presentation fixture used by the browser acceptance probe, not real consumer generation progress. It demonstrates large inventories and combined status selection.

These samples contain no consumer execution data or credentials. They are PR review artifacts and are excluded from the installed harness package.
