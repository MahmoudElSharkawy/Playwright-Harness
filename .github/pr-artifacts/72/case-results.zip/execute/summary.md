# Synthetic execution

Execution: execute-f5047eb3-1d1b-433a-97a7-460ea22a7867

| Scenario | Outcome | Checked / observed / mixed |
|---|---|---|
| tc\-101\-r1 | PASS | 1 / 0 / 0 |
| tc\-102\-r1 | FAIL | 1 / 0 / 0 |
| tc\-103\-r1 | BLOCKED | 0 / 0 / 0 |
| tc\-104\-r1 | NOT_RUN | 0 / 0 / 0 |

Exclusions: 0. Defect groups: 1.
