# Harness execution report

Run: run-c3017ef3-84e4-4067-ac45-2c1860a7ae70

Status: **PASS** · Stability: **stable**

PASS: 1 · FAIL: 0 · BLOCKED: 0 · SKIPPED: 0 · NEEDS_REVIEW: 0

Verdicts supplied by the execution core. Sensitive values and raw evidence bodies are omitted.

## tc-101-r1 — PASS

Stability: stable · required: 1 · evaluated: 1 · passed: 1 · failed: 0 · indeterminate: 0 · notEvaluated: 0

Required lifecycle: complete

### Phases and attempts

- EXERCISE / s001 / attempt-8623956a-1790-4df4-b5c4-1124da0034d9 (attempt 1): SUCCESS; NONE; effect none; 29 ms
  - Invocation: s001; evidence: artifact-441a5b50-108c-4954-9551-ff301b1790ca, artifact-ddf33091-41f6-43e9-b4e4-31f3905f2151, artifact-fdbe0714-c242-4b4f-a352-155f21c5e91c, artifact-f4477e07-2150-438f-84d9-6b3711cf2fe8
  - Affected resources: none
  - Assertion condition-db7aa4c5cf41eb0542243dff: PASS; reliable: true; evidence: artifact-ddf33091-41f6-43e9-b4e4-31f3905f2151, artifact-441a5b50-108c-4954-9551-ff301b1790ca, artifact-fdbe0714-c242-4b4f-a352-155f21c5e91c

### Resources and lifecycle

No tracked resources.

### Selected outputs

No selected outputs.

## Operation provenance

- s001: api; target api; capability apiReads; inline; execute-refinement; version 1.0.0; fingerprint 7accdf26c0de419b8370838cc1a2be00a3226d0b25753ba418636415c59059ce

## Evidence inventory

Paths are relative to the original run directory. Bytes are not copied into this report.

- artifact-441a5b50-108c-4954-9551-ff301b1790ca: observation; evidence/artifact-441a5b50-108c-4954-9551-ff301b1790ca.json; tc-101-r1 / attempt-8623956a-1790-4df4-b5c4-1124da0034d9; 79 bytes; SHA256 9e47e5d8b2dcff8fba8cb83b78065863e6f15c74cf06e5b6df95c959cff9430d
- artifact-ddf33091-41f6-43e9-b4e4-31f3905f2151: response; evidence/artifact-ddf33091-41f6-43e9-b4e4-31f3905f2151.json; tc-101-r1 / attempt-8623956a-1790-4df4-b5c4-1124da0034d9; 66 bytes; SHA256 5cbc95dae1ddd6cc64407708061aa678e0d42cf8ecfb56a8e26d797d2046764b
- artifact-fdbe0714-c242-4b4f-a352-155f21c5e91c: assertion; evidence/artifact-fdbe0714-c242-4b4f-a352-155f21c5e91c.json; tc-101-r1 / attempt-8623956a-1790-4df4-b5c4-1124da0034d9; 105 bytes; SHA256 b615ab2a2fa4e4390b7364e512a3c2a77b43df6111b659a884bb721cae7a3963
- artifact-f4477e07-2150-438f-84d9-6b3711cf2fe8: observation; evidence/artifact-f4477e07-2150-438f-84d9-6b3711cf2fe8.json; tc-101-r1 / attempt-8623956a-1790-4df4-b5c4-1124da0034d9; 82 bytes; SHA256 bf3202366552cf7ee558077d1555eba45bd6da711a0313730b1fa0f65d838b22
