# Harness execution report

Run: run-e8a093f9-4974-4e5e-9b24-01338af071c9

Status: **FAIL** · Stability: **stable**

PASS: 0 · FAIL: 1 · BLOCKED: 0 · SKIPPED: 0 · NEEDS_REVIEW: 0

Verdicts supplied by the execution core. Sensitive values and raw evidence bodies are omitted.

## tc-102-r1 — FAIL

Stability: stable · required: 1 · evaluated: 1 · passed: 0 · failed: 1 · indeterminate: 0 · notEvaluated: 0

Required lifecycle: complete

### Phases and attempts

- EXERCISE / s001 / attempt-d458de48-e31b-4865-b470-0f0125232257 (attempt 1): ASSERTION_FAILURE; ASSERTION; effect none; 17 ms
  - Invocation: s001; evidence: artifact-7d83c44c-5700-4fa6-ac23-c2b92e875049, artifact-80c35577-3d06-4df0-a14d-8ef3e1129fa0, artifact-ca949090-7f1d-41ac-ad80-5b2590137cec, artifact-d84200fa-a883-4598-8736-3e6938123794
  - Affected resources: none
  - Assertion condition-a0154d7dbe7371d2ed2b1331: FAIL; reliable: true; evidence: artifact-80c35577-3d06-4df0-a14d-8ef3e1129fa0, artifact-7d83c44c-5700-4fa6-ac23-c2b92e875049, artifact-ca949090-7f1d-41ac-ad80-5b2590137cec

### Resources and lifecycle

No tracked resources.

### Selected outputs

No selected outputs.

## Operation provenance

- s001: api; target api; capability apiReads; inline; execute-refinement; version 1.0.0; fingerprint 4e36a57e79ea5beb4fc3d8bf4d757613d788b0bab998984c1cff2a46d76acc1d

## Evidence inventory

Paths are relative to the original run directory. Bytes are not copied into this report.

- artifact-7d83c44c-5700-4fa6-ac23-c2b92e875049: observation; evidence/artifact-7d83c44c-5700-4fa6-ac23-c2b92e875049.json; tc-102-r1 / attempt-d458de48-e31b-4865-b470-0f0125232257; 79 bytes; SHA256 94dec7444d8620f1b9d8d8728e165b814d727e1f45f5946ecc8c637f23113dce
- artifact-80c35577-3d06-4df0-a14d-8ef3e1129fa0: response; evidence/artifact-80c35577-3d06-4df0-a14d-8ef3e1129fa0.json; tc-102-r1 / attempt-d458de48-e31b-4865-b470-0f0125232257; 66 bytes; SHA256 316fe9814d68be00a82c44956d126905ee6f647dcd063a418b9b9fa730ec05c5
- artifact-ca949090-7f1d-41ac-ad80-5b2590137cec: assertion; evidence/artifact-ca949090-7f1d-41ac-ad80-5b2590137cec.json; tc-102-r1 / attempt-d458de48-e31b-4865-b470-0f0125232257; 106 bytes; SHA256 3d74b96e84f926fbb4fc14b3b5b8c639cdfcf7990cf0f2df934feab0a899df21
- artifact-d84200fa-a883-4598-8736-3e6938123794: observation; evidence/artifact-d84200fa-a883-4598-8736-3e6938123794.json; tc-102-r1 / attempt-d458de48-e31b-4865-b470-0f0125232257; 82 bytes; SHA256 bf3202366552cf7ee558077d1555eba45bd6da711a0313730b1fa0f65d838b22
